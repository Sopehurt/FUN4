/*
 * kalman_imu.h
 *
 *  Created on: Oct 28, 2024
 *      Author: beamkeerati
 */

#ifndef INC_KALMAN_IMU_H_
#define INC_KALMAN_IMU_H_

#include "main.h"
#include <arm_math.h>

#define STATE_SIZE 6
#define MEASUREMENT_SIZE 6
#define CONTROL_SIZE 3

// Kalman Filter structure definition
typedef struct {
    // Matrices
    arm_matrix_instance_f32 A;   // State transition matrix
    arm_matrix_instance_f32 B;   // Control matrix
    arm_matrix_instance_f32 Q;   // Process noise covariance
    arm_matrix_instance_f32 R;   // Measurement noise covariance
    arm_matrix_instance_f32 C;   // Observation matrix
    arm_matrix_instance_f32 P;   // State covariance matrix
    arm_matrix_instance_f32 K;   // Kalman gain
    arm_matrix_instance_f32 x;   // State vector
    arm_matrix_instance_f32 z;   // Measurement vector
    arm_matrix_instance_f32 u;   // Control input vector

    // Data arrays for matrices
    float32_t A_data[STATE_SIZE * STATE_SIZE];
    float32_t B_data[STATE_SIZE * CONTROL_SIZE];
    float32_t Q_data[STATE_SIZE * STATE_SIZE];
    float32_t R_data[MEASUREMENT_SIZE * MEASUREMENT_SIZE];
    float32_t C_data[MEASUREMENT_SIZE * STATE_SIZE];
    float32_t P_data[STATE_SIZE * STATE_SIZE];
    float32_t K_data[STATE_SIZE * MEASUREMENT_SIZE];
    float32_t x_data[STATE_SIZE];
    float32_t z_data[MEASUREMENT_SIZE];
    float32_t u_data[CONTROL_SIZE];
    float32_t gyro_angle[CONTROL_SIZE];

} Kalman;

void Kalman_Init(Kalman* kf);
void Kalman_Predict(Kalman* kf, arm_matrix_instance_f32* gyro_vector);
void Kalman_Update(Kalman* kf, arm_matrix_instance_f32* acc_vector);

#endif /* INC_KALMAN_IMU_H_ */
