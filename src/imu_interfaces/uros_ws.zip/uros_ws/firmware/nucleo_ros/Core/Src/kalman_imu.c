/*
 * kalman_imu.c
 *
 *  Created on: Oct 28, 2024
 *      Author: beamkeerati
 */

#include "kalman_imu.h"
#include <arm_math.h>

// Removed inclusion of <string.h>

// Time step (adjust as needed)
float32_t dt = 0.01f;
int inversion_status;
void Kalman_Init(Kalman* kf) {
    // Initialize matrix structures using the data arrays in the Kalman structure
    arm_mat_init_f32(&kf->A, STATE_SIZE, STATE_SIZE, kf->A_data);
    arm_mat_init_f32(&kf->B, STATE_SIZE, CONTROL_SIZE, kf->B_data);
    arm_mat_init_f32(&kf->Q, STATE_SIZE, STATE_SIZE, kf->Q_data);
    arm_mat_init_f32(&kf->R, MEASUREMENT_SIZE, MEASUREMENT_SIZE, kf->R_data);
    arm_mat_init_f32(&kf->C, MEASUREMENT_SIZE, STATE_SIZE, kf->C_data);
    arm_mat_init_f32(&kf->P, STATE_SIZE, STATE_SIZE, kf->P_data);
    arm_mat_init_f32(&kf->K, STATE_SIZE, MEASUREMENT_SIZE, kf->K_data);
    arm_mat_init_f32(&kf->x, STATE_SIZE, 1, kf->x_data);
    arm_mat_init_f32(&kf->z, MEASUREMENT_SIZE, 1, kf->z_data);
    arm_mat_init_f32(&kf->u, CONTROL_SIZE, 1, kf->u_data);

    // Initialize matrices with appropriate values

    // State transition matrix A
    kf->A_data[0] = 1.0f;  kf->A_data[1] = 0.0f;  kf->A_data[2] = 0.0f;  kf->A_data[3] = -dt;  kf->A_data[4] = 0.0f;  kf->A_data[5] = 0.0f;
    kf->A_data[6] = 0.0f;  kf->A_data[7] = 1.0f;  kf->A_data[8] = 0.0f;  kf->A_data[9] = 0.0f;  kf->A_data[10] = -dt; kf->A_data[11] = 0.0f;
    kf->A_data[12] = 0.0f; kf->A_data[13] = 0.0f; kf->A_data[14] = 1.0f; kf->A_data[15] = 0.0f;  kf->A_data[16] = 0.0f; kf->A_data[17] = -dt;
    kf->A_data[18] = 0.0f; kf->A_data[19] = 0.0f; kf->A_data[20] = 0.0f; kf->A_data[21] = 1.0f; kf->A_data[22] = 0.0f; kf->A_data[23] = 0.0f;
    kf->A_data[24] = 0.0f; kf->A_data[25] = 0.0f; kf->A_data[26] = 0.0f; kf->A_data[27] = 0.0f; kf->A_data[28] = 1.0f; kf->A_data[29] = 0.0f;
    kf->A_data[30] = 0.0f; kf->A_data[31] = 0.0f; kf->A_data[32] = 0.0f; kf->A_data[33] = 0.0f; kf->A_data[34] = 0.0f; kf->A_data[35] = 1.0f;

    // Control matrix B
    kf->B_data[0] = dt;   kf->B_data[1] = 0.0f;  kf->B_data[2] = 0.0f;
    kf->B_data[3] = 0.0f; kf->B_data[4] = dt;    kf->B_data[5] = 0.0f;
    kf->B_data[6] = 0.0f; kf->B_data[7] = 0.0f;  kf->B_data[8] = dt;
    kf->B_data[9] = 0.0f; kf->B_data[10] = 0.0f; kf->B_data[11] = 0.0f;
    kf->B_data[12] = 0.0f;kf->B_data[13] = 0.0f; kf->B_data[14] = 0.0f;
    kf->B_data[15] = 0.0f;kf->B_data[16] = 0.0f; kf->B_data[17] = 0.0f;

    // Observation matrix C
    // Only the first three rows are non-zero
    kf->C_data[0] = 1.0f; kf->C_data[1] = 0.0f; kf->C_data[2] = 0.0f; kf->C_data[3] = 0.0f; kf->C_data[4] = 0.0f; kf->C_data[5] = 0.0f;
    kf->C_data[6] = 0.0f; kf->C_data[7] = 1.0f; kf->C_data[8] = 0.0f; kf->C_data[9] = 0.0f; kf->C_data[10] = 0.0f; kf->C_data[11] = 0.0f;
    kf->C_data[12] = 0.0f;kf->C_data[13] = 0.0f;kf->C_data[14] = 1.0f;kf->C_data[15] = 0.0f;kf->C_data[16] = 0.0f;kf->C_data[17] = 0.0f;
    // Remaining rows are zeros
    for (int i = 18; i < 36; i++) {
        kf->C_data[i] = 0.0f;
    }

    // Process noise covariance Q
    float32_t Q2_dt2 = 1.0f * 1.0f * dt * dt;
    // Initialize Q_data
    for (int i = 0; i < STATE_SIZE * STATE_SIZE; i++) {
        kf->Q_data[i] = 0.0f;
    }
    kf->Q_data[0] = Q2_dt2;
    kf->Q_data[7] = Q2_dt2;
    kf->Q_data[14] = Q2_dt2;

    // Measurement noise covariance R
    float32_t R2= 1.0f * 1.0f;
    // Initialize R_data
    for (int i = 0; i < MEASUREMENT_SIZE * MEASUREMENT_SIZE; i++) {
        kf->R_data[i] = 0.0f;
    }
    kf->R_data[0] = R2;
    kf->R_data[7] = R2;
    kf->R_data[14] = R2;

    // Initial state covariance P
    for (int i = 0; i < STATE_SIZE * STATE_SIZE; i++) {
        kf->P_data[i] = 0.0f;
    }
    kf->P_data[0] = 1.0f;
    kf->P_data[7] = 1.0f;
    kf->P_data[14] = 1.0f;
    kf->P_data[21] = 1.0f;
    kf->P_data[28] = 1.0f;
    kf->P_data[35] = 1.0f;

    // Initial state estimate x
    for (int i = 0; i < STATE_SIZE; i++) {
        kf->x_data[i] = 0.0f;
    }

    // Initial control input u
    for (int i = 0; i < CONTROL_SIZE; i++) {
        kf->u_data[i] = 0.0f;
    }

    // Initialize gyro_angle
    kf->gyro_angle[0] = 0.0f;
    kf->gyro_angle[1] = 0.0f;
    kf->gyro_angle[2] = 0.0f;
}


void init_rotation_matrix(arm_matrix_instance_f32 *R, float32_t theta, float32_t phi) {
    // Temporary variables to hold trigonometric values
    float32_t cos_theta = arm_cos_f32(theta);
    float32_t sin_theta = arm_sin_f32(theta);
    float32_t cos_phi = arm_cos_f32(phi);
    float32_t sin_phi = arm_sin_f32(phi);

    // Define the elements of the rotation matrix
    float32_t Rm_data[9] = {
        cos_theta,         0.0f,       -cos_phi * sin_theta,
        0.0f,              1.0f,        sin_phi,
        sin_theta,         0.0f,        cos_phi * cos_theta
    };

    // Initialize the matrix structure with these values
    arm_mat_init_f32(R, 3, 3, Rm_data);
}


void Kalman_Predict(Kalman* kf, arm_matrix_instance_f32* gyro_vector) {

	//------------State Extrapolation start-----------------//
	// Predict next state: x = A * x + B * u
	float32_t x_pred_data[STATE_SIZE];
	arm_matrix_instance_f32 x_pred;
	arm_mat_init_f32(&x_pred, STATE_SIZE, 1, x_pred_data);

	// x_pred = A * x
	arm_mat_mult_f32(&kf->A, &kf->x, &x_pred);

	// u = R^-1 * gyro_vector
	kf->gyro_angle[0] += gyro_vector->pData[0] * dt;  // First element
	kf->gyro_angle[1] += gyro_vector->pData[1] * dt;  // Second element
	kf->gyro_angle[2] += gyro_vector->pData[2] * dt;  // Third element

	// Initialize the rotation matrix R
	arm_matrix_instance_f32 R;
	init_rotation_matrix(&R, kf->gyro_angle[0], kf->gyro_angle[1]);

	// Find the inverse of R and compute the control input u
	float32_t R_inv_custom_data[MEASUREMENT_SIZE * MEASUREMENT_SIZE];
	inversion_status = compute_3x3_inverse(kf->R.pData, R_inv_custom_data);

	if (inversion_status == 0) {
	    arm_matrix_instance_f32 R_inv_custom;
	    arm_mat_init_f32(&R_inv_custom, MEASUREMENT_SIZE, MEASUREMENT_SIZE, R_inv_custom_data);
	    arm_mat_mult_f32(&R_inv_custom, gyro_vector, &kf->u);
	} else {
	    arm_fill_f32(0.0f, kf->u.pData, CONTROL_SIZE);
	}
	//------------State Extrapolation end-----------------//

	//------------Covariance Extrapolation start-----------------//
	// Update state covariance: P = A * P * A^T + Q
	float32_t P_pred_data[STATE_SIZE * STATE_SIZE];
	arm_matrix_instance_f32 P_pred;
	arm_mat_init_f32(&P_pred, STATE_SIZE, STATE_SIZE, P_pred_data);

	// P_pred = A * P
	arm_mat_mult_f32(&kf->A, &kf->P, &P_pred);

	// A_T = transpose(A)
	float32_t A_T_data[STATE_SIZE * STATE_SIZE];
	arm_matrix_instance_f32 A_T;
	arm_mat_init_f32(&A_T, STATE_SIZE, STATE_SIZE, A_T_data);
	arm_mat_trans_f32(&kf->A, &A_T);

	// P = P_pred * A_T
	arm_mat_mult_f32(&P_pred, &A_T, &kf->P);

	// P = P + Q
	arm_mat_add_f32(&kf->P, &kf->Q, &kf->P);
	//------------Covariance Extrapolation end-----------------//


}

void Kalman_Update(Kalman* kf, arm_matrix_instance_f32* acc_vector) {

	//------------Kalman Gain start-----------------//
	// Ct = transpose(C)
	float32_t Ct_data[STATE_SIZE * MEASUREMENT_SIZE];
	arm_matrix_instance_f32 Ct;
	arm_mat_init_f32(&Ct, STATE_SIZE, MEASUREMENT_SIZE, Ct_data);
	arm_mat_trans_f32(&kf->C, &Ct);

	// P * Ct
	float32_t PCt_data[STATE_SIZE * MEASUREMENT_SIZE];
	arm_matrix_instance_f32 PCt;
	arm_mat_init_f32(&PCt, STATE_SIZE, MEASUREMENT_SIZE, PCt_data);
	arm_mat_mult_f32(&kf->P, &Ct, &PCt);

	// S = C * P * C^T + R
	float32_t S_data[MEASUREMENT_SIZE * MEASUREMENT_SIZE];
	arm_matrix_instance_f32 S;
	arm_mat_init_f32(&S, MEASUREMENT_SIZE, MEASUREMENT_SIZE, S_data);

	float32_t CP_data[MEASUREMENT_SIZE * STATE_SIZE];
	arm_matrix_instance_f32 CP;
	arm_mat_init_f32(&CP, MEASUREMENT_SIZE, STATE_SIZE, CP_data);
	arm_mat_mult_f32(&kf->C, &kf->P, &CP);

	arm_mat_mult_f32(&CP, &Ct, &S); // S = C * P * C^T
	arm_mat_add_f32(&S, &kf->R, &S); // S = S + R

	// Compute inverse of S
	float32_t S_inv_data[MEASUREMENT_SIZE * MEASUREMENT_SIZE];
	arm_matrix_instance_f32 S_inv;
	arm_mat_init_f32(&S_inv, MEASUREMENT_SIZE, MEASUREMENT_SIZE, S_inv_data);
	if (arm_mat_inverse_f32(&S, &S_inv) != ARM_MATH_SUCCESS) {
	    return;
	}

	// K = P * Ct * S_inv
	arm_mat_mult_f32(&PCt, &S_inv, &kf->K);
	//------------Kalman Gain stop-----------------//

	//------------State Update start-----------------//
	// Update measurement z (from accelerometer)
	arm_copy_f32(acc_vector->pData, kf->z.pData, MEASUREMENT_SIZE);

	// y = z - C * x (Innovation)
	float32_t y_data[MEASUREMENT_SIZE];
	arm_matrix_instance_f32 y;
	arm_mat_init_f32(&y, MEASUREMENT_SIZE, 1, y_data);

	float32_t Cx_data[MEASUREMENT_SIZE];
	arm_matrix_instance_f32 Cx;
	arm_mat_init_f32(&Cx, MEASUREMENT_SIZE, 1, Cx_data);
	arm_mat_mult_f32(&kf->C, &kf->x, &Cx);

	arm_mat_sub_f32(&kf->z, &Cx, &y);

	// x = x + K * y
	float32_t Ky_data[STATE_SIZE];
	arm_matrix_instance_f32 Ky;
	arm_mat_init_f32(&Ky, STATE_SIZE, 1, Ky_data);
	arm_mat_mult_f32(&kf->K, &y, &Ky);

	arm_mat_add_f32(&kf->x, &Ky, &kf->x);
	//------------State Update end-----------------//

	//------------Covariance Update start-----------------//
	// Update covariance matrix P: P = (I - K * C) * P
	float32_t Temp_data[STATE_SIZE * STATE_SIZE], I_data[STATE_SIZE * STATE_SIZE];
	arm_matrix_instance_f32 Temp, I;
	arm_mat_init_f32(&Temp, STATE_SIZE, STATE_SIZE, Temp_data);
	arm_mat_mult_f32(&kf->K, &kf->C, &Temp);

	arm_mat_init_f32(&I, STATE_SIZE, STATE_SIZE, I_data);
	for (int i = 0; i < STATE_SIZE * STATE_SIZE; i++) {
	    I_data[i] = (i % (STATE_SIZE + 1) == 0) ? 1.0f : 0.0f;
	}
	arm_mat_sub_f32(&I, &Temp, &Temp);
	arm_mat_mult_f32(&Temp, &kf->P, &kf->P);
	//------------Covariance Update end-----------------//


}


int compute_3x3_inverse(const float32_t *input, float32_t *output) {
    float32_t det;
    float32_t invDet;

    // Compute the determinant
    det = input[0]*(input[4]*input[8] - input[5]*input[7]) -
          input[1]*(input[3]*input[8] - input[5]*input[6]) +
          input[2]*(input[3]*input[7] - input[4]*input[6]);

    if (det == 0.0f) {
        // Singular matrix
        return -1;
    }

    invDet = 1.0f / det;

    // Compute the inverse matrix elements
    output[0] = (input[4]*input[8] - input[5]*input[7]) * invDet;
    output[1] = (input[2]*input[7] - input[1]*input[8]) * invDet;
    output[2] = (input[1]*input[5] - input[2]*input[4]) * invDet;

    output[3] = (input[5]*input[6] - input[3]*input[8]) * invDet;
    output[4] = (input[0]*input[8] - input[2]*input[6]) * invDet;
    output[5] = (input[2]*input[3] - input[0]*input[5]) * invDet;

    output[6] = (input[3]*input[7] - input[4]*input[6]) * invDet;
    output[7] = (input[1]*input[6] - input[0]*input[7]) * invDet;
    output[8] = (input[0]*input[4] - input[1]*input[3]) * invDet;

    return 0;
}
