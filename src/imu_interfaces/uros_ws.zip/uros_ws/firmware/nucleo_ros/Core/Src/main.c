/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2024 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"
#include "dma.h"
#include "i2c.h"
#include "iwdg.h"
#include "usart.h"
#include "tim.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <rcl/rcl.h>
#include <rcl/error_handling.h>
#include <rclc/rclc.h>
#include <rclc/executor.h>
#include <uxr/client/transport.h>
#include <rmw_microxrcedds_c/config.h>
#include <rmw_microros/rmw_microros.h>

#include <micro_ros_utilities/string_utilities.h>
#include <std_msgs/msg/int32.h>
#include <sensor_msgs/msg/imu.h>
#include <imu_interfaces/srv/imu_calibration.h>
#include <std_srvs/srv/set_bool.h>

#include <mpu6050.h>
#include <arm_math.h>
#include "kalman_imu.h"
#include <math.h>

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef struct {
	double x;
	double y;
	double z;
} offset3d_t;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define G2M_S2 9.80665
#define DEG2RAD M_PI/180.0
#define MPU6050_ADDR 0xD0
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
#define RCLSOFTCHECK(fn) if (fn!= RCL_RET_OK){};
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
uint8_t test = 0;
MPU6050_t MPU6050;
offset3d_t accel_offset;
offset3d_t gyro_offset;

bool is_calib = false;
bool imu_status = false;

rcl_publisher_t mpu6050_publisher;
std_msgs__msg__Int32 msg;
sensor_msgs__msg__Imu mpu6050_msg;
imu_interfaces__srv__ImuCalibration_Request mpu6050_request;
imu_interfaces__srv__ImuCalibration_Response mpu6050_response;
std_srvs__srv__SetBool_Request imu_status_request;
std_srvs__srv__SetBool_Response imu_status_response;



rclc_support_t support;
rcl_node_t node;
rclc_executor_t executor;
rcl_timer_t mpu6050_timer;
rcl_service_t mpu6050_service;
rcl_service_t imu_status_service;
// sync time
const int timeout_ms = 1000;

uint16_t state_size = 2;        // Adjust based on your implementation
uint16_t measurement_size = 1;  // Adjust based on your implementation
//Kalman Filter instance
Kalman kf;

// Matrices for gyro and accelerometer data
arm_matrix_instance_f32 gyro_vector;
float32_t gyro_data[3];  // Adjust size if needed

arm_matrix_instance_f32 acc_vector;
float32_t acc_data[3];   // Adjust size if needed
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
void MX_FREERTOS_Init(void);
/* USER CODE BEGIN PFP */
bool cubemx_transport_open(struct uxrCustomTransport *transport);
bool cubemx_transport_close(struct uxrCustomTransport *transport);
size_t cubemx_transport_write(struct uxrCustomTransport *transport,
		const uint8_t *buf, size_t len, uint8_t *err);
size_t cubemx_transport_read(struct uxrCustomTransport *transport, uint8_t *buf,
		size_t len, int timeout, uint8_t *err);

void* microros_allocate(size_t size, void *state);
void microros_deallocate(void *pointer, void *state);
void* microros_reallocate(void *pointer, size_t size, void *state);
void* microros_zero_allocate(size_t number_of_elements, size_t size_of_element,
		void *state);

void timer_callback(rcl_timer_t *timer, int64_t last_call_time);
void service_callback(const void *request_msg, void *response_msg);
void service_imu_status_callback(const void *request_msg, void *response_msg);
void send_imu();
void calib_manual();
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

void StartDefaultTask(void *argument) {

	// micro-ROS configuration

	rmw_uros_set_custom_transport(
	true, (void*) &hlpuart1, cubemx_transport_open, cubemx_transport_close,
			cubemx_transport_write, cubemx_transport_read);

	rcl_allocator_t freeRTOS_allocator =
			rcutils_get_zero_initialized_allocator();
	freeRTOS_allocator.allocate = microros_allocate;
	freeRTOS_allocator.deallocate = microros_deallocate;
	freeRTOS_allocator.reallocate = microros_reallocate;
	freeRTOS_allocator.zero_allocate = microros_zero_allocate;

	if (!rcutils_set_default_allocator(&freeRTOS_allocator)) {
		printf("Error on default allocators (lmine %d)\n", __LINE__);
	}

	// Initialize Kalman Filter

	// Initialize gyro and accelerometer matrices

	// micro-ROS app
	rcl_allocator_t allocator = rcl_get_default_allocator();
	rcl_init_options_t init_options = rcl_get_zero_initialized_init_options();

	RCLSOFTCHECK(rcl_init_options_init(&init_options, allocator));
	RCLSOFTCHECK(rcl_init_options_set_domain_id(&init_options, 6));

	rclc_support_init_with_options(&support, 0, NULL, &init_options,
			&allocator);
	rclc_node_init_default(&node, "stm_node", "", &support);

	rclc_timer_init_default(&mpu6050_timer, &support, RCL_MS_TO_NS(10),
			timer_callback);

	rclc_publisher_init_best_effort(&mpu6050_publisher, &node,
			ROSIDL_GET_MSG_TYPE_SUPPORT(sensor_msgs, msg, Imu),
			"mpu6050_publisher");

	GPIO_PinState button = HAL_GPIO_ReadPin(B1_GPIO_Port, B1_Pin);
	uint8_t num_executor = 1;

	if (button == 1) {
		rclc_service_init_default(&mpu6050_service, &node,
				ROSIDL_GET_SRV_TYPE_SUPPORT(imu_interfaces, srv,
						ImuCalibration), "mpu6050_calibration");
		num_executor++;
	} else {
		is_calib = true;

		calib_manual();
	}


		rclc_service_init_default(&imu_status_service, &node,
				ROSIDL_GET_SRV_TYPE_SUPPORT(std_srvs, srv,
						SetBool), "imu/status");
		num_executor++;

	executor = rclc_executor_get_zero_initialized_executor();
	rclc_executor_init(&executor, &support.context, num_executor, &allocator);
	rclc_executor_add_timer(&executor, &mpu6050_timer);
	if (button == 1) {
		rclc_executor_add_service(&executor, &mpu6050_service, &mpu6050_request,
				&mpu6050_response, service_callback);
	}
	rclc_executor_add_service(&executor, &imu_status_service, &imu_status_request,
			&imu_status_response, service_imu_status_callback);

	rclc_executor_spin(&executor);

	msg.data = 0;
	mpu6050_msg.header.frame_id = micro_ros_string_utilities_init("imu_frame");

}
void service_imu_status_callback(const void *request_msg, void *response_msg) {
	// Cast messages to expected types
	std_srvs__srv__SetBool_Request *req_in =
			(std_srvs__srv__SetBool_Request*) request_msg;

	std_srvs__srv__SetBool_Response *res_in =
			(std_srvs__srv__SetBool_Response*) response_msg;

	res_in->success = imu_status;


	HAL_GPIO_TogglePin(LD2_GPIO_Port, LD2_Pin);

}
void calib_manual() {
	accel_offset.x = -0.23589159161485732;
	accel_offset.y = -0.12156750476812013;
	accel_offset.z = 2.3384331373211964;

	gyro_offset.x = 0.020513321070373059;
	gyro_offset.y = -0.0092084370649419718;
	gyro_offset.z = -0.0060364943292355745;

	// Set linear acceleration covariance matrix
	mpu6050_msg.linear_acceleration_covariance[0] = 0.0010342195980777389;
	mpu6050_msg.linear_acceleration_covariance[1] = 9.218723456183185e-06;
	mpu6050_msg.linear_acceleration_covariance[2] = 6.248436922962616e-05;
	mpu6050_msg.linear_acceleration_covariance[3] = 9.218723456183185e-06;
	mpu6050_msg.linear_acceleration_covariance[4] = 0.0009725568625819581;
	mpu6050_msg.linear_acceleration_covariance[5] = 1.661640991038075e-05;
	mpu6050_msg.linear_acceleration_covariance[6] = 6.248436922962616e-05;
	mpu6050_msg.linear_acceleration_covariance[7] = 1.661640991038075e-05;
	mpu6050_msg.linear_acceleration_covariance[8] = 0.0030693489094885114;

	// Set angular velocity covariance matrix
	mpu6050_msg.angular_velocity_covariance[0] = 2.7507199720404456e-06;
	mpu6050_msg.angular_velocity_covariance[1] = 9.95703603336696e-08;
	mpu6050_msg.angular_velocity_covariance[2] = 1.793040478518077e-08;
	mpu6050_msg.angular_velocity_covariance[3] = 9.95703603336696e-08;
	mpu6050_msg.angular_velocity_covariance[4] = 4.043263793611839e-06;
	mpu6050_msg.angular_velocity_covariance[5] = 1.275264435451253e-09;
	mpu6050_msg.angular_velocity_covariance[6] = 1.793040478518077e-08;
	mpu6050_msg.angular_velocity_covariance[7] = 1.275264435451253e-09;
	mpu6050_msg.angular_velocity_covariance[8] = 2.5358130376575874e-06;
}
void send_imu() {
	MPU6050_Read_All(&hi2c1, &MPU6050);
	if (is_calib) {
		acc_data[0] = G2M_S2 * MPU6050.Ax - accel_offset.x;
		acc_data[1] = G2M_S2 * MPU6050.Ay - accel_offset.y;
		acc_data[2] = G2M_S2 * MPU6050.Az - accel_offset.z;

		gyro_data[0] = DEG2RAD * MPU6050.Gx - gyro_offset.x;
		gyro_data[1] = DEG2RAD * MPU6050.Gy - gyro_offset.y;
		gyro_data[2] = DEG2RAD * MPU6050.Gz - gyro_offset.z;
	} else {
		// Fill the gyro and accelerometer data arrays
		acc_data[0] = G2M_S2 * MPU6050.Ax;
		acc_data[1] = G2M_S2 * MPU6050.Ay;
		acc_data[2] = G2M_S2 * MPU6050.Az;

		gyro_data[0] = DEG2RAD * MPU6050.Gx;
		gyro_data[1] = DEG2RAD * MPU6050.Gy;
		gyro_data[2] = DEG2RAD * MPU6050.Gz;

	}
	arm_mat_init_f32(&gyro_vector, 3, 1, gyro_data);
	arm_mat_init_f32(&acc_vector, 3, 1, acc_data);
	// Perform Kalman Filter prediction and update
//	Kalman_Predict(&kf, &gyro_vector);
//	Kalman_Update(&kf, &acc_vector);

	mpu6050_msg.header.stamp.sec = rmw_uros_epoch_millis() / 1000;
	mpu6050_msg.header.stamp.nanosec = rmw_uros_epoch_nanos();

	mpu6050_msg.linear_acceleration.x = acc_data[0];
	mpu6050_msg.linear_acceleration.y = acc_data[1];
	mpu6050_msg.linear_acceleration.z = acc_data[2];

	mpu6050_msg.angular_velocity.x = gyro_data[0];
	mpu6050_msg.angular_velocity.y = gyro_data[1];
	mpu6050_msg.angular_velocity.z = gyro_data[2];

	mpu6050_msg.orientation.x = (kf.x.pData[0]);
	mpu6050_msg.orientation.y = (kf.x.pData[1]);

	mpu6050_msg.orientation.z = MPU6050.KalmanAngleX;
	mpu6050_msg.orientation.w = MPU6050.KalmanAngleY;

	RCLSOFTCHECK(rcl_publish(&mpu6050_publisher, &mpu6050_msg, NULL));

}

void service_callback(const void *request_msg, void *response_msg) {
	// Cast messages to expected types
	imu_interfaces__srv__ImuCalibration_Request *req_in =
			(imu_interfaces__srv__ImuCalibration_Request*) request_msg;

	imu_interfaces__srv__ImuCalibration_Response *res_in =
			(imu_interfaces__srv__ImuCalibration_Response*) response_msg;

	for (int i = 0; i < 9; i++) {
		mpu6050_msg.linear_acceleration_covariance[i] =
				req_in->imu_calib.linear_acceleration_covariance[i];
		mpu6050_msg.angular_velocity_covariance[i] =
				req_in->imu_calib.angular_velocity_covariance[i];
	}

	accel_offset.x = req_in->imu_calib.linear_acceleration.x;
	accel_offset.y = req_in->imu_calib.linear_acceleration.y;
	accel_offset.z = req_in->imu_calib.linear_acceleration.z;

	gyro_offset.x = req_in->imu_calib.angular_velocity.x;
	gyro_offset.y = req_in->imu_calib.angular_velocity.y;
	gyro_offset.z = req_in->imu_calib.angular_velocity.z;

	is_calib = true;

	res_in->success = true;

	HAL_GPIO_TogglePin(LD2_GPIO_Port, LD2_Pin);

}

void timer_callback(rcl_timer_t *timer, int64_t last_call_time) {

	if (timer != NULL) {
		// Perform actions
		rmw_uros_sync_session(timeout_ms);
		send_imu();

		// Synchronize time with the agent

		if(HAL_I2C_IsDeviceReady(&hi2c1, MPU6050_ADDR, 1, 10) != HAL_OK){
		  // flag = 0
			imu_status = false;
		}
		else{
		  //flag = 1
			imu_status = true;
		}


		HAL_IWDG_Refresh(&hiwdg);
	}
}

/* USER CODE END 0 */

/**
 * @brief  The application entry point.
 * @retval int
 */
int main(void) {

	/* USER CODE BEGIN 1 */

	/* USER CODE END 1 */

	/* MCU Configuration--------------------------------------------------------*/

	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();

	/* USER CODE BEGIN Init */

	/* USER CODE END Init */

	/* Configure the system clock */
	SystemClock_Config();

	/* USER CODE BEGIN SysInit */

	/* USER CODE END SysInit */

	/* Initialize all configured peripherals */
	MX_GPIO_Init();
	MX_DMA_Init();
	MX_LPUART1_UART_Init();
	MX_I2C1_Init();
	MX_IWDG_Init();
	MX_TIM2_Init();
	/* USER CODE BEGIN 2 */

	while (MPU6050_Init(&hi2c1) == 1); // Todo: Enable IMU first (blocking inital function) or Initial Failed
	imu_status = true;
	Kalman_Init(&kf);
	HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, SET);

	/* USER CODE END 2 */

	/* Init scheduler */
	osKernelInitialize();

	/* Call init function for freertos objects (in cmsis_os2.c) */
	MX_FREERTOS_Init();

	/* Start scheduler */
	osKernelStart();

	/* We should never get here as control is now taken by the scheduler */

	/* Infinite loop */
	/* USER CODE BEGIN WHILE */
	while (1) {
		/* USER CODE END WHILE */

		/* USER CODE BEGIN 3 */
//		HAL_IWDG_Refresh(&hiwdg);
//		HAL_Delay(5000);
	}
	/* USER CODE END 3 */
}

/**
 * @brief System Clock Configuration
 * @retval None
 */
void SystemClock_Config(void) {
	RCC_OscInitTypeDef RCC_OscInitStruct = { 0 };
	RCC_ClkInitTypeDef RCC_ClkInitStruct = { 0 };

	/** Configure the main internal regulator output voltage
	 */
	HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1_BOOST);

	/** Initializes the RCC Oscillators according to the specified parameters
	 * in the RCC_OscInitTypeDef structure.
	 */
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI
			| RCC_OSCILLATORTYPE_LSI;
	RCC_OscInitStruct.HSIState = RCC_HSI_ON;
	RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
	RCC_OscInitStruct.LSIState = RCC_LSI_ON;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
	RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
	RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV4;
	RCC_OscInitStruct.PLL.PLLN = 85;
	RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
	RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
	RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) {
		Error_Handler();
	}

	/** Initializes the CPU, AHB and APB buses clocks
	 */
	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
			| RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
	RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
	RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

	if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK) {
		Error_Handler();
	}
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
 * @brief  Period elapsed callback in non blocking mode
 * @note   This function is called  when TIM1 interrupt took place, inside
 * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
 * a global variable "uwTick" used as application time base.
 * @param  htim : TIM handle
 * @retval None
 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) {
	/* USER CODE BEGIN Callback 0 */

	/* USER CODE END Callback 0 */
	if (htim->Instance == TIM1) {
		HAL_IncTick();
	}
	if (htim->Instance == TIM2) {

		test = 1;
	}
	/* USER CODE BEGIN Callback 1 */

	/* USER CODE END Callback 1 */
}

/**
 * @brief  This function is executed in case of error occurrence.
 * @retval None
 */
void Error_Handler(void) {
	/* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();
	while (1) {
	}
	/* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
