## [1.0.1] - 2021-06-05
- Fix bug https://github.com/leech001/MPU6050/issues/3#issue-893041350;
